//: ![Swift book cover](Apple-Book-Cover.png)
//:
//:
//: ## ![](swiftLogo43.png) The Swift Programming Language Book
//:
//: This is the official Apple Swift Language Guide taken from The Swift Programming Language Book and converted into Swift playgrounds.
//:
//: © Copyright [3DaysOfSwift.com](https://www.3DaysOfSwift.com). All rights reserved.
//:
//: [3DaysOfSwift.com](https://www.3DaysOfSwift.com) | [Online Course](https://www.3DaysOfSwift.com)
//:
//: v1 | Swift v5.9+ | Xcode 15+
//:
/*:
 */
//:
//: -------------------
//: ## Book Contents
//:
//: * *Topic 1:*   [The Basics](1%20The%20Basics)
//: * *Topic 2:*   [Basic Operators](2%20Basic%20Operators)
//: * *Topic 3:*   [Strings and Characters](3%20Strings%20and%20Characters)
//: * *Topic 4:*   [Collection Types](4%20Collection%20Types)
//: * *Topic 5:*   [Control Flow](5%20Control%20Flow)
//: * *Topic 6:*   [Functions](6%20Functions)
//: * *Topic 7:*   [Closures](7%20Closures)
//: * *Topic 8:*   [Enumerations](8%20Enumerations)
//: * *Topic 9:*   [Structures and Classes](9%20Classes%20and%20Structures)
//: * *Topic 10:*  [Properties](10%20Properties)
//: * *Topic 11:*  [Methods](11%20Methods)
//: * *Topic 12:*  [Subscripts](12%20Subscripts)
//: * *Topic 13:*  [Inheritance](13%20Inheritance)
//: * *Topic 14:*  [Initialization](14%20Initialization)
//: * *Topic 15:*  [Deinitialization](15%20Deinitialization)
//: * *Topic 16:*  [Optional Chaining](16%20Optional%20Chaining)
//: * *Topic 17:*  [Error Handling](17%20Error%20Handling)
//: * *Topic 18:*  [Concurrency](18%20Concurrency)
//: * *Topic 19:*  [Type Casting](19%20Type%20Casting)
//: * *Topic 20:*  [Nested Types](20%20Nested%20Types)
//: * *Topic 21:*  [Extensions](21%20Extensions)
//: * *Topic 22:*  [Protocols](22%20Protocols)
//: * *Topic 23:*  [Generics](23%20Generics)
//: * *Topic 24:*  [Opaque Types](24%20Opaque%20Types)
//: * *Topic 25:*  [Automatic Reference Counting](25%20Automatic%20Reference%20Counting)
//: * *Topic 26:*  [Memory Safety](26%20Memory%20Safety)
//: * *Topic 27:*  [Access Control](27%20Access%20Control)
//: * *Topic 28:*  [Advanced Operators](28%20Advanced%20Operators)
//:
//: -------------------
//:
//: ## Executable Code Examples
//:
//: To execute each code example, hover over the line number and press the run button that appears.
//:
//: 👉 Try it with the code below.
//:
//: -------------------
//:


let maximumNumberOfLoginAttempts = 10
var currentLoginAttempt = 0
func login() {
    guard currentLoginAttempt < maximumNumberOfLoginAttempts else {
        return
    }
    currentLoginAttempt += 1
    print("logging in..")
}
login()


//: -------------------
//:
//: ![](3DaysIcon146.png)  [3DaysOfSwift.com](https://www.3DaysOfSwift.com) | [Email Us](mailto:helloworld@3daysofswift.com?subject=Hello)
//:
//: Why not take our intensive 3-day [online course](https://www.3DaysOfSwift.com)?
//:
/*:
 */
//: -------------------
//:
//: [Begin  ▶](@next)
//:
//: -------------------
//:
//: ## ![The 3 Days Of Swift Logo](3DaysIcon128.png) 3 Days Of Swift
//:
//: © Copyright. All rights reserved.
//:
//: 🧕🏻🙋🏽‍♂️👨🏿‍💼👩🏼‍💼👩🏻‍💻💁🏼‍♀️👨🏼‍💼🙋🏻‍♂️🙋🏻‍♀️👩🏼‍💻🙋🏿💁🏽‍♂️🙋🏽‍♀️🙋🏿‍♀️🧕🏾🙋🏼‍♂️
//:
//: Welcome to our community of [3DaysOfSwift.com](https://www.3DaysOfSwift.com) students!
